<footer class="bg-brand-dark border-t border-white/5 pt-16" style="padding-bottom: calc(7rem + env(safe-area-inset-bottom, 0px));">
    <div class="max-w-7xl mx-auto px-6">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
            <div class="md:col-span-2">
                <a href="{{ route('home') }}" class="flex items-center gap-3 mb-4 group">
                    <div style="
                        width: 52px;
                        height: 52px;
                        border-radius: 14px;
                        overflow: hidden;
                        border: 1px solid rgba(255,255,255,0.10);
                        background: transparent;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        transition: box-shadow 0.3s ease, border-color 0.3s ease;
                    " class="logo-wrap-footer">
                        <img src="{{ asset('images/logo.png') }}" alt="Codemir IT Experts"
                             loading="lazy"
                             style="
                                 width: 100%;
                                 height: 100%;
                                 object-fit: contain;
                                 mix-blend-mode: screen;
                                 filter: brightness(1.1) contrast(1.05);
                             ">
                    </div>
                </a>
                <p class="font-inter text-brand-muted text-sm leading-relaxed max-w-sm mb-6">
                    Elevating businesses with top-notch IT services — from web development to AI tool integrations. Based in Pakistan, serving globally.
                </p>
                <div class="flex gap-3">
                    <a href="https://www.linkedin.com/company/codemir-it-experts/" target="_blank" aria-label="LinkedIn"
                       class="w-9 h-9 bg-brand-card border border-white/10 rounded-lg flex items-center justify-center text-brand-muted hover:text-brand-blue hover:border-brand-blue transition">
                        <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.32 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.79M6.88 8.56a1.68 1.68 0 0 0 1.68-1.68c0-.93-.75-1.69-1.68-1.69a1.69 1.69 0 0 0-1.69 1.69c0 .93.76 1.68 1.69 1.68m1.39 9.94v-8.37H5.5v8.37h2.77z"/></svg>
                    </a>
                    <a href="https://www.instagram.com/codemiritexpert/" target="_blank" aria-label="Instagram"
                       class="w-9 h-9 bg-brand-card border border-white/10 rounded-lg flex items-center justify-center text-brand-muted hover:text-brand-blue hover:border-brand-blue transition">
                        <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
                    </a>
                    <a href="https://www.facebook.com/profile.php?id=61564927201888" target="_blank" aria-label="Facebook"
                       class="w-9 h-9 bg-brand-card border border-white/10 rounded-lg flex items-center justify-center text-brand-muted hover:text-brand-blue hover:border-brand-blue transition">
                        <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v3.385z"/></svg>
                    </a>
                    <a href="https://github.com/ZaidShahid15" target="_blank" aria-label="GitHub"
                       class="w-9 h-9 bg-brand-card border border-white/10 rounded-lg flex items-center justify-center text-brand-muted hover:text-brand-blue hover:border-brand-blue transition">
                        <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/></svg>
                    </a>
                    <a href="mailto:codemiritexpert@gmail.com" aria-label="Email"
                       class="w-9 h-9 bg-brand-card border border-white/10 rounded-lg flex items-center justify-center text-brand-muted hover:text-brand-blue hover:border-brand-blue transition">
                        <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
                    </a>
                </div>
            </div>

            <div>
                <h4 class="font-grotesk text-sm text-white uppercase tracking-wider mb-5">Pages</h4>
                <ul class="space-y-3 font-inter text-sm text-brand-muted">
                    <li><a href="{{ route('home') }}"         class="hover:text-white transition">Home</a></li>
                    <li><a href="{{ route('services') }}"     class="hover:text-white transition">Services</a></li>
                    <li><a href="{{ route('ai-solutions') }}" class="hover:text-white transition">AI Solutions</a></li>
                    <li><a href="{{ route('work') }}"         class="hover:text-white transition">Our Work</a></li>
                    <li><a href="{{ route('blog') }}"         class="hover:text-white transition">Blog</a></li>
                    <li><a href="{{ route('about') }}"        class="hover:text-white transition">About</a></li>
                    <li><a href="{{ route('contact') }}"      class="hover:text-white transition">Contact</a></li>
                </ul>
            </div>

            <div>
                <h4 class="font-grotesk text-sm text-white uppercase tracking-wider mb-5">Services</h4>
                <ul class="space-y-3 font-inter text-sm text-brand-muted">
                    <li><a href="{{ route('services.detail', 'custom-websites') }}" class="hover:text-white transition">Custom Websites</a></li>
                    <li><a href="{{ route('services.detail', 'web-applications') }}" class="hover:text-white transition">Web Applications</a></li>
                    <li><a href="{{ route('services.detail', 'ai-tools') }}" class="hover:text-white transition">AI Tool Integration</a></li>
                    <li><a href="{{ route('services.detail', 'ecommerce') }}" class="hover:text-white transition">eCommerce Development</a></li>
                    <li><a href="{{ route('services.detail', 'api-development') }}" class="hover:text-white transition">API Development</a></li>
                    <li><a href="{{ route('services.detail', 'business-systems') }}" class="hover:text-white transition">Business Systems</a></li>
                </ul>
            </div>
        </div>

        <div class="border-t border-white/5 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-center md:text-left">
            <p class="font-inter text-brand-muted text-sm">© {{ date('Y') }} Codemir IT Experts. All Rights Reserved.</p>
            <div class="flex flex-wrap justify-center gap-6 font-inter text-sm text-brand-muted">
                <a href="{{ route('privacy') }}" class="hover:text-white transition">Privacy Policy</a>
                <a href="{{ route('terms') }}" class="hover:text-white transition">Terms & Conditions</a>
                <a href="{{ route('sitemap') }}" class="hover:text-white transition">Sitemap</a>
            </div>
        </div>
    </div>
</footer>

<style>
.logo-wrap-footer:hover {
    box-shadow: 0 0 18px rgba(59, 130, 246, 0.35), 0 0 0 1px rgba(59,130,246,0.25);
    border-color: rgba(59,130,246,0.35) !important;
}
</style>
