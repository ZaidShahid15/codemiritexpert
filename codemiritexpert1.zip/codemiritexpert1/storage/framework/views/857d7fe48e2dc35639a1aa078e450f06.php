<?php $__env->startSection('title', 'Insights & Blog | Codemir IT Experts'); ?>
<?php $__env->startSection('meta_description', 'Deep dives into custom Laravel systems, RESTful API engineering, and AI automation workflows written by our experts.'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('components.page-hero', [
    'eyebrow'     => 'Our Blog',
    'title'       => 'Developer Insights &<br><span class="text-brand-blue">Tech Articles</span>',
    'description' => 'Read our latest insights on PHP Laravel engineering, generative AI integrations, and custom business workflow automations.',
    'cta1Label'   => 'Contact Us',
    'cta1Route'   => 'contact',
    'cta2Label'   => 'Read Articles',
    'cta2Route'   => 'blog',
    'badges'      => ['Laravel Best Practices', 'OpenAI APIs', 'Custom CRM/ERP', 'API Design', 'Software Performance'],
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<section class="py-24 bg-brand-black min-h-screen">
    <div class="max-w-6xl mx-auto px-6">
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div data-aos="fade-up" data-aos-delay="<?php echo e($loop->index * 80); ?>">
                <div class="bg-brand-card border border-white/5 rounded-2xl overflow-hidden hover:border-brand-blue/30 transition-all duration-300 hover:-translate-y-1 group h-full flex flex-col justify-between">
                    
                    
                    <div class="relative h-48 bg-gradient-to-br from-brand-blue/20 to-purple-900/40 border-b border-white/5 flex items-center justify-center p-6 text-center select-none overflow-hidden">
                        <div class="absolute -top-12 -left-12 w-28 h-28 bg-brand-blue/20 rounded-full blur-xl pointer-events-none"></div>
                        <div class="absolute -bottom-12 -right-12 w-28 h-28 bg-purple-500/20 rounded-full blur-xl pointer-events-none"></div>
                        
                        <div class="z-10">
                            <span class="font-grotesk text-xs uppercase tracking-widest text-brand-blue/80 bg-brand-blue/10 border border-brand-blue/20 px-3 py-1 rounded-full mb-3 inline-block">
                                <?php echo e($post['category']); ?>

                            </span>
                            <h4 class="font-playfair text-lg font-bold text-white line-clamp-2"><?php echo e($post['title']); ?></h4>
                        </div>
                    </div>

                    
                    <div class="p-6 flex-1 flex flex-col justify-between">
                        <div>
                            <div class="flex items-center gap-3 text-xs text-brand-muted mb-4 font-grotesk font-medium">
                                <span><?php echo e($post['date']); ?></span>
                                <span>·</span>
                                <span><?php echo e($post['read_time']); ?></span>
                            </div>
                            <p class="font-inter text-brand-muted text-sm leading-relaxed mb-6">
                                <?php echo e($post['summary']); ?>

                            </p>
                        </div>

                        <a href="<?php echo e(route('blog.detail', $slug)); ?>" class="inline-flex items-center gap-2 text-sm font-semibold text-brand-blue group-hover:text-brand-blue-hover transition">
                            Read Article
                            <span class="transform translate-x-0 group-hover:translate-x-1 transition-transform">&rarr;</span>
                        </a>
                    </div>

                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
</section>


<?php echo $__env->make('components.faq', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\abubaker_portfolio\codemiritexpert\resources\views/pages/blog.blade.php ENDPATH**/ ?>